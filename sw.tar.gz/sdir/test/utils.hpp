#pragma once
/// \file
///
///
#include <cassert>
#include <type_traits>
